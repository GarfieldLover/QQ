(function () {
    if (navigator.userAgent.match(/(iPad|iPhone|iPod).*?QQ/g)) {

        /**
         * QQApi provides api for web pages which are embeded into qq client
         * web pages could use these api to invoke client capabilities
         * you may include this script in your page like this:
         *
         * <script src="http://qqlocal/api/qqapi.js"></script>
         */
        mqq = {
            /**
             * Helper method for opening an url
             * @param url
             */
            _openURL: function(url){
                //create an iframe to send the request
                var i = document.createElement('iframe');
                i.style.display = 'none';
                i.src = url;
                document.body.appendChild(i);
                
                //read return value
                var returnValue = iOSQQApi.__RETURN_VALUE;
                iOSQQApi.__RETURN_VALUE = undefined;

                //destory the iframe
                i.parentNode.removeChild(i);

                return returnValue;
            },
                
            _invokeClientMethod: function(module, name, parameters){
                var url = 'jsbridge://' + module + '/' + name + '?p=' + encodeURIComponent(JSON.stringify(parameters || {}));
                console.log('[API]' + url);
                var r = iOSQQApi._openURL(url);
                return r ? r.result : null;
            },
                
            _createGlobalFuncForCallback: function(callback){
                if (callback) {
                    var name = '__GLOBAL_CALLBACK__' + (iOSQQApi.__globalFuncIndex++);
                    window[name] = function(){
                        var args = arguments;
                        var func = (typeof callback == "function") ? callback : window[callback];
                        //we need to use setimeout here to avoid ui thread being frezzen
                        setTimeout(function(){ func.apply(null, args); }, 0);
                    };
                    return name;
                }
                return null;
            },
            
            /**
             mgenliu 13-11-09: 在Oscar的_createGlobalFuncForCallback基础上：
             修改1：删除了setTimeout，改为直接调用函数。
             修改2：将callback类型的判断放在function执行外。
             修改原因：用在重力、罗盘这种每秒超频繁调用的Callback情景中。

             @param {Function|String} callback 回调函数
             */
            _createGlobalFuncForDirectCallback: function(callback){
                if (callback) {
                    //如果callback是函数，返回一个字符串来代表该函数的全局变量名称
                    if (typeof callback == "function") {
                        var name = '__GLOBAL_CALLBACK__' + (iOSQQApi.__globalFuncIndex++);
                        window[name] = callback;
                        return name;
                    }
                    //如果callback变量不是function，判断window[callback]是function
                    var func = window[callback];
                    if(typeof func == "function"){
                        return callback;
                    }
                }
                return null;
            },
            
            /**
             mgenliu 13-11-11:
             好多JS接口需要改成Android那样回调的形式，这类回调不需要传给本地，直接在JS中根据结果回调。
             这个方法就是用来执行这个操作，意在使其他方法最大限度得少写代码。

             @param {Function|String} callback 回调函数
             @param {Array} args 回调函数参数（数组）
             */
            _invokeCallbackWithArgs: function(callback, args) {
                //如果callback为空，我们什么都不做。
                if (callback) {
                    //用于回调的function对象
                    var func = null;
                    //临时变量，用来存放window[callback]，避免重复调用window[callback]
                    var tmp;
                    if (typeof callback == "function") {
                        func = callback;
                    }
                    //如果callback变量不是function，判断window[callback]是function
                    else if((tmp = window[callback]) && typeof tmp == 'function') {
                        func = tmp;
                    }
                    if (func) {
                        setTimeout(function(){ func.apply(null, args); }, 0);
                    }
                }
            },
            
            //兼容旧接口
            isAppInstalled: function(){
                return iOSQQApi.app.isAppInstalled.apply(null, arguments);
            },
            isAppInstalledBatch: function(){
                return iOSQQApi.app.isAppInstalledBatch.apply(null, arguments);
            },
                
            __globalFuncIndex: 0,
            __RETURN_VALUE: undefined,
            
            /**
             * Device Module ================================================================================================
             */
            device: {
                isMobileQQ:         function(){ return iOSQQApi._invokeClientMethod('device', 'isMobileQQ');        },
                systemName:         function(){ return iOSQQApi._invokeClientMethod('device', 'systemName');        },
                systemVersion:      function(){ return iOSQQApi._invokeClientMethod('device', 'systemVersion');     },
                model:              function(){ return iOSQQApi._invokeClientMethod('device', 'model');             },
                modelVersion:       function(){ return iOSQQApi._invokeClientMethod('device', 'modelVersion');      },
                qqVersion:          function(){ return iOSQQApi._invokeClientMethod('device', 'qqVersion');         },
                qqBuild:            function(){ return iOSQQApi._invokeClientMethod('device', 'qqBuild');           },
                networkStatus:      function(){ return iOSQQApi._invokeClientMethod('device', 'networkStatus');     },
                networkType:        function() {return iOSQQApi._invokeClientMethod('device', 'networkStatus');     },
                /*
                 *获取webview 类型，场景 ，返回 sting  1 通用 2 优惠券 3 我的优惠 4 二维码
                 */
                webviewType:        function() {return iOSQQApi._invokeClientMethod('device', 'webviewType');     },
 
                /*
                 *获取设备信息
                 @param {Function} callback(data)
                    {Object} data
                         - Boolean isMobileQQ //是否手机QQ
                         - String systemName //系统名，如”iPhone OS”
                         - String systemVersion //系统版本，如”6.0”
                         - String model  //机器系列，如”iPhone”, “iPod touch”
                         - String modelVersion //机型，如”iPhone 6”
                */
                getDeviceInfo: function(callback) {
                    var result =
                    {
                        'isMobileQQ': this.isMobileQQ(),
                        'systemName': this.systemName(),
                        'systemVersion': this.systemVersion(),
                        'model': this.model(),
                        'modelVersion': this.modelVersion()
                    };
                    mqq._invokeCallbackWithArgs(callback, [result]);
                    return result;
                },
                
                /**
                 获取客户端信息
                 @param {Function} callback(data)
                   {Object} data
                        - String qqVersion
                        - String qqBuild
                 */
                getClientInfo: function(callback) {
                    var result =
                    {
                        'qqVersion': this.qqVersion(),
                        'qqBuild': this.qqBuild()
                    };
                    mqq._invokeCallbackWithArgs(callback, [result]);
                    return result;           
                },
                
                /**
                 获取当前用户的网络类型
                 @param {Function} callback(result)
                     - {int} result
                        0: NotReachable
                        1: ReachableViaWiFi
                        2: ReachableVia3G
                        3: ReachableVia2G
                        4. Unknown   未知类型网络
                 */
                getNetworkType: function(callback) {
                    var result = this.networkStatus();
                    mqq._invokeCallbackWithArgs(callback, [result]);
                    return result;
                },

                /**
                 * 获取当前webview的类型
                 * @param  {Function} callback(result)
                 *         - {int}  result
                 *          1 通用 
                 *          2 优惠券 
                 *          3 我的优惠 
                 *          4 二维码
                 */
                getWebViewType: function(callback){
                    var result = this.webviewType();
                    mqq._invokeCallbackWithArgs(callback, [result]);
                    return result;
                }
            },
            
            /**
             * Application Module ===========================================================================================
             */
            app: {
                /**
                 查询单个应用是否已安装
                 @param {String} scheme 比如'mqq'
                 @return {Boolean}
                 */
                isAppInstalled: function(scheme, callback) {
                    var result = iOSQQApi._invokeClientMethod('app', 'isInstalled', {'scheme':scheme});
                    mqq._invokeCallbackWithArgs(callback, [result]);
                    return result;
                },
            
                /**
                 批量查询指定应用是否已安装
                 @param {Array<String>} schemes 比如['mqq', 'mqqapi']
                 @return {Array<Boolean>}
                 */
                isAppInstalledBatch: function(schemes, callback) {
                    var result = iOSQQApi._invokeClientMethod('app', 'batchIsInstalled', {'schemes':schemes});
                    mqq._invokeCallbackWithArgs(callback, [result]);
                    return result;
                },
                
                /**
                 mgenliu 13-11-11:
                 4.6更新，已做4.5兼容。
                 @params {Object}
                     - String appID
                     - String paramsStr
                 
                 oscartang 13-11-18
                 旧接口名(launchApp)废弃，和android统一成launchAppWithTokens
                 */
                launchAppWithTokens: function(appID, paramsStr) {
                    //判断参数是4.6的接口样式
                    if (typeof appID == 'object') {
                        return iOSQQApi._invokeClientMethod('app', 'launchApp', appID);
                    }
                    //判断参数是4.5的接口样式
                    return iOSQQApi._invokeClientMethod('app', 'launchApp', {'appID':appID, 'paramsStr':paramsStr});
                },
                
                /**
                 发送趣味表情
                 @param type 业务类型，一起玩为funnyFace
                 @param sessionType 会话类型，1（群）、2（讨论组）、3（C2C聊天）
                 @param gcode 会话ID，针对群，这里是外部可见的群号
                 @param guin 针对群，这里是内部群号。讨论组和C2C类型这里指定为0
                 @param faceID 标识特定表情，到connect.qq.com上申请
                 */
                sendFunnyFace: function(params) {
                    iOSQQApi._invokeClientMethod('app', 'sendFunnyFace', params);
                }
                
            },
            
            /**
             * Data Module ==================================================================================================
             */
            data: {
                userInfo: function(){
                    return iOSQQApi._invokeClientMethod('data', 'userInfo');
                },
                
                /**
                 拉取地理位置，当系统关闭整个地理位置时，返回错误，并且第一次启动弹alert 询问框，
                 */
                currentLocation: function(callback){
                    var callbackName = callback ? iOSQQApi._createGlobalFuncForCallback(callback) : null;
                    return iOSQQApi._invokeClientMethod('data', 'queryCurrentLocation', {'callback':callbackName});
                },
                
                /**
                 拉取地理位置，当系统关闭整个地理位置时，返回错误，不弹alert 询问框，
                 */
                currentLocationNoAlert: function(callback){
                    var callbackName = callback ? iOSQQApi._createGlobalFuncForCallback(callback) : null;
                    return iOSQQApi._invokeClientMethod('data', 'queryCurrentLocation_NoAlert', {'callback':callbackName});
                },
                
                /**
                 拉取json数据
                 @param {String} url
                 @param {Object} params 请求参数
                 @param {Object} options 请求配置
                     - method: 'GET'/'POST', 默认为GET
                     - timeout: 超时时间，默认无超时时间
                 @param {Function/String} 回调函数（或该函数的名字），参数格式：function(responseText, context, httpStatusCode){ ... }
                 @param {Object} context 会原样传入到callback内
                 */
                fetchJson: function(url, params, options, callback, context){
                    //query parameters
                    components = ["_t=" + (new Date()).getTime()];
                    if (params) {
                        for(var key in params){
                            components.push(key + '=' + encodeURIComponent(params[key]));
                        }
                    };
                    options = options || {};
                    //callback function
                    var callbackName = callback ? iOSQQApi._createGlobalFuncForCallback(callback) : null;
                    //send request to url via client
                    iOSQQApi._invokeClientMethod('data', 'fetchJson', {
                        'method': options['method'] || 'GET',
                        'timeout': options['timeout'] || -1,
                        'url': url,
                        'params': components.join('&'),
                        'callback': callbackName,
                        'context': JSON.stringify(context)
                    });
                },
                /**
                 批量获取当前用户指定应用的openid
                 @param {Array<String>} appID数组
                 @param {Object} options
                 @param {Function/String} callback
                 @param {Object} context
                 */
                batchFetchOpenID: function(appIDs, options, callback, context){
                    iOSQQApi.data.fetchJson(
                        'http://cgi.connect.qq.com/api/get_openids_by_appids',
                        {'appids': JSON.stringify(appIDs)},
                        null, callback, null
                    );
                },
                /**
                 通过发送NSNotification来给客户端传数据
                 @param {String} notificationName 通知名
                 @param {*} value 数据
                 @param {Function/String} [callback]
                 */
                send: function(notificationName, value, callback){
                    var callbackName = callback ? iOSQQApi._createGlobalFuncForCallback(callback) : null;
                    iOSQQApi._invokeClientMethod('data', 'send', {
                        'notificationName': notificationName,
                        'value': value,
                        'callback': callbackName
                    });
                },
                
                /**
                 开始接收游戏状态变更的PUSH消息
                 @param {Object} params
                     - {Number} appID
                 @param {Function} callback 收到push消息后调用callback传数据给js的回调
                 */
                startSyncData: function(params, callback) {
                    var callbackName = iOSQQApi._createGlobalFuncForCallback(callback);
                    if (callbackName) {
                        params.callback = callbackName;
                        iOSQQApi._invokeClientMethod('data', 'startSyncData', params);
                    }
                },
                
                /**
                 停止接收游戏状态变更的PUSH消息
                 @param {Object} params
                     - {Number} appID
                 */
                stopSyncData: function(params) {
                    iOSQQApi._invokeClientMethod('data', 'stopSyncData', params);
                },
 /*
  @param {Object}
  - String callid
  - String url
  */
 getUrlImage: function(params,callback){
 var callbackName = callback ? iOSQQApi._createGlobalFuncForCallback(callback) : null;
 iOSQQApi._invokeClientMethod('data', 'getUrlImage', {
                              'callback': callbackName,
                              'params': params
                              });
 },
 /*
  @param params {Object}
  callid: String	// 用来标示请求id, 返回时把该值传回
  host: String	// 如果host不为空, 且是该页面的域名的父域名, 则往host写, 如果为空则往页面的域名写, 其他为错误
  path: String	// 区分业务
  key: String     // 数据对应的key
  */
 readH5Data: function(params,callback){
 var callbackName = callback ? iOSQQApi._createGlobalFuncForCallback(callback) : null;
 
 iOSQQApi._invokeClientMethod('data', 'readWebviewBizData', {
                              'callback': callbackName,
                              'params': params
                              });
 },
 /*
  @param params {Object}
  callid: String	// 用来标示请求id, 返回时把该值传回
  host: String	// 如果host不为空, 且是该页面的域名的父域名, 则往host写, 如果为空则往页面的域名写, 其他为错误
  path: String	// 区分业务
  key: String     // 数据对应的key
  data: String    // 数据
  */
 writeH5Data: function(params,callback){
 
 var callbackName = callback ? iOSQQApi._createGlobalFuncForCallback(callback) : null;
 
 iOSQQApi._invokeClientMethod('data', 'writeWebviewBizData', {
                              'callback': callbackName,
                              'params': params
                              });
 },
 /*
  @param params {Object}
  callid: String	// 用来标示请求id, 返回时把该值传回
  host: String    //如果host不为空, 且是该页面的域名的父域名, 则清除该host, 如果为空则清除页面的域名, 其他为错误
  */
 
 deleteH5DataByHost: function(params,callback){
 var callbackName = callback ? iOSQQApi._createGlobalFuncForCallback(callback) : null;
 iOSQQApi._invokeClientMethod('data', 'deleteWebviewBizData', {
                              'callback': callbackName,
                              'delallhostdata': 1,
                              'params': params
                              });
 },
 
 /*
  @param params {Object}
  callid: String	// 用来标示请求id, 返回时把该值传回
  host: String    //如果host不为空, 且是该页面的域名的父域名, 则往host读, 如果为空则往页面的域名读, 其他为错误
  path: String	// 区分业务, 为空则报错.
  key: String		// 数据对应的key, 如果为空则删除整个path
  */
 deleteH5Data: function(params,callback){
 
 var callbackName = callback ? iOSQQApi._createGlobalFuncForCallback(callback) : null;
 iOSQQApi._invokeClientMethod('data', 'deleteWebviewBizData', {
                              'callback': callbackName,
                              'params': params
                              });
 },
 pbReport: function(type, data){
 
 iOSQQApi._invokeClientMethod('data', 'pbReport', {
                              'type': type,
                              'data': data
                              });
 },
 
 getPageLoadStamp: function(callback) {
 
 var callbackName = callback ? iOSQQApi._createGlobalFuncForCallback(callback) : null;
 iOSQQApi._invokeClientMethod('data', 'getPageLoadStamp', {'callback':callbackName});
 
 },
 /*
  @param url: String	// 设置什么，webview分享出去的就是什么url
  */
 setShareURL: function(url)
 {
 iOSQQApi._invokeClientMethod('data', 'setShareURL', {'url':url});
 },
 /*
  @param params {Object}
  share_url: String	    页面可以定制分享出去的url，去掉某些敏感参数等，如空，用页面url
  title: String         分享的标题,必填
  desc: String	        分享的摘要,必填
  image_url: String		图片URL
  */
 setShareInfo: function(params)
 {
 iOSQQApi._invokeClientMethod('data', 'setShareInfo', {'params':params});
 },
                /**
                 查询本地缓存是否已关注公众号 
                 @param {Object} params
                      - {String} uin 公众帐号的uin
                 @param {Function} callback(result)
                      - result = {ret:0, response:{"follow":true}}
                        ret == 0, 调用成功
                */
                isFollowUin: function(params, callback) {
                    params = params || {};
                    params['callback'] = iOSQQApi._createGlobalFuncForCallback(callback);
                    iOSQQApi._invokeClientMethod('data', 'isFollowUin', params);
                },
                /**
                 关注公众号 
                 @param {Object} params
                      - {String} uin 公众帐号的uin
                 @param {Function} callback(result)
                      - result ＝ {ret:0, response:{}}
                        ret == 0, 调用成功
                */
                followUin: function(params, callback) {
                    params = params || {};
                    params['callback'] = iOSQQApi._createGlobalFuncForCallback(callback);
                    iOSQQApi._invokeClientMethod('data', 'followUin', params);
                }
            },
            coupon: {
                /**
                领取优惠券

                4.6参数（函数继续兼容4.5）
                @param {Object}
                     - int bid //商家ID
                     - int sourceId //商户来源ID
                     - int cid //优惠券ID
                @param {Function} [callback(retCode)] //回调函数
                */
                addCoupon: function(bid, cid, sourceId, callback){
                    //4.6
                    if (typeof bid == 'object') {
                        var params = bid;
                        //cid（第二个参数）是callback
                        if(params.callback = iOSQQApi._createGlobalFuncForCallback(cid))
                            iOSQQApi.coupon.addCouponWithCity(params.bid, params.cid, params.sourceId, '', params.callback);
                    }
                    //兼容4.5
                    else {
                        iOSQQApi.coupon.addCouponWithCity(bid, cid, sourceId, '', callback);
                    }
                },
                addCouponWithCity: function(bid, cid, sourceId, city, callback){
                    var callbackName = callback ? iOSQQApi._createGlobalFuncForCallback(callback) : null;
                    iOSQQApi._invokeClientMethod('coupon', 'addCoupon', {
                        'bid': bid,
                        'cid': cid,
                        'sourceId': sourceId,
                        'city': city,
                        'callback': callbackName
                    });
                },
                /**
                删除优惠券

                4.6参数（函数继续兼容4.5）
                @param {Object}
                     - int bid //商家ID
                     - int sourceId //商户来源ID
                     - int cid //优惠券ID
                @param {Function} [callback(retCode)] //回调函数
                */
                removeCoupon: function(bid, cid, sourceId, callback){
                    var callbackName = callback ? iOSQQApi._createGlobalFuncForCallback(callback) : null;
                    //4.6
                    if (typeof bid == 'object') {
                        var params = bid;
                        //cid（第二个参数）是callback
                        if(params.callback = iOSQQApi._createGlobalFuncForCallback(cid))
                            iOSQQApi._invokeClientMethod('coupon', 'removeCoupon', params);
                    }
                    //兼容4.5
                    else { 
                        iOSQQApi._invokeClientMethod('coupon', 'removeCoupon', {
                            'bid': bid,
                            'cid': cid,
                            'sourceId': sourceId,
                            'callback': callbackName
                        });
                    }
                },
                /**
                收藏商家

                4.6参数（函数继续兼容4.5）
                @param {Object}
                     - int bid //商家ID
                     - int sourceId //商户来源ID
                @param {Function} [callback(retCode)] //回调函数
                */
                addFavourBusiness: function(bid, sourceId, callback){
                    var callbackName = callback ? iOSQQApi._createGlobalFuncForCallback(callback) : null;
                    //4.6
                    if (typeof bid == 'object') {
                        var params = bid;
                        //sourceId（第二个参数）是callback
                        if(params.callback = iOSQQApi._createGlobalFuncForCallback(sourceId))
                            iOSQQApi._invokeClientMethod('coupon', 'addFavourBusiness', params);
                    }
                    //兼容4.5
                    else { 
                        iOSQQApi._invokeClientMethod('coupon', 'addFavourBusiness', {
                            'bid': bid,
                            'sourceId': sourceId,
                            'callback': callbackName
                        });
                    }
                },

                /**
                删除收藏商家

                4.6参数（函数继续兼容4.5）
                @param {Object}
                     - int bid //商家ID
                     - int sourceId //商户来源ID
                @param {Function} [callback(retCode)] //回调函数
                */
                removeFavourBusiness: function(bid, sourceId, callback){
                    var callbackName = callback ? iOSQQApi._createGlobalFuncForCallback(callback) : null;
                    //4.6
                    if (typeof bid == 'object') {
                        var params = bid;
                        //sourceId（第二个参数）是callback
                        if(params.callback = iOSQQApi._createGlobalFuncForCallback(sourceId))
                            iOSQQApi._invokeClientMethod('coupon', 'removeFavourBusiness', params);
                    }
                    //兼容旧接口
                    else { 
                        iOSQQApi._invokeClientMethod('coupon', 'removeFavourBusiness', {
                            'bid': bid,
                            'sourceId': sourceId,
                            'callback': callbackName
                        });
                    }
                },

                /**
                判断指定的优惠券是否已收藏

                4.6参数（函数继续兼容4.5）
                @param {Object}
                     - int bid //商家ID
                     - int sourceId //商户来源ID
                     - int cid //优惠券ID

                @param {Function} [callback(retCode)] //回调函数
                */
                isFavourCoupon: function(bid, cid, sourceId, callback){
                    var callbackName = callback ? iOSQQApi._createGlobalFuncForCallback(callback) : null;
                    //4.6
                    if (typeof bid == 'object') {
                        var params = bid;
                        //cid（第二个参数）是callback
                        if(params.callback = iOSQQApi._createGlobalFuncForCallback(cid))
                            iOSQQApi._invokeClientMethod('coupon', 'isFavourCoupon', params);
                    }
                    //兼容4.5
                    else { 
                        iOSQQApi._invokeClientMethod('coupon', 'isFavourCoupon', {
                            'bid': bid,
                            'cid': cid,
                            'sourceId': sourceId,
                            'callback': callbackName
                        });
                    }
                },
                /**
                判断是否我收藏的商家  

                4.6参数（函数继续兼容4.5）
                @param {Object}
                     - int bid //商家ID
                     - int sourceId //商户来源ID
                @param {Function} [callback(Boolean result)]
                */
                isFavourBusiness: function(bid, sourceId, callback){
                    var callbackName = callback ? iOSQQApi._createGlobalFuncForCallback(callback) : null;
                    //4.6
                    if (typeof bid == 'object') {
                        var params = bid;
                        //sourceId（第二个参数）是callback
                        if(params.callback = iOSQQApi._createGlobalFuncForCallback(sourceId))
                            iOSQQApi._invokeClientMethod('coupon', 'isFavourBusiness', params);
                    }
                    //兼容4.5
                    else { 
                        iOSQQApi._invokeClientMethod('coupon', 'isFavourBusiness', {
                            'bid': bid,
                            'sourceId': sourceId,
                            'callback': callbackName
                        });
                    }
                },
                gotoCouponHome: function(){
                    iOSQQApi._invokeClientMethod('coupon', 'gotoCouponHome');
                },
                gotoCoupon: function(bid, cid, sourceId){
                    iOSQQApi._invokeClientMethod('coupon', 'gotoCoupon', {
                        'bid': bid,
                        'cid': cid,
                        'sourceId': sourceId
                    });
                },
 goToCouponHomePage: function(params){
 
 iOSQQApi._invokeClientMethod('coupon', 'goToCouponHomePage',{'params':params});
 }
 
            },
            pay: {
                /**
                 发起购买请求
                 @param {Object} options
                 - {String}  apple_pay_source 调用来源，区分不同的场景，找soapyang 统一定义
                 - {int}    [qq_product_id] QQ 商品ID  1 表情类   2 会员  3超级会员
                 - {String} [qq_product_name] 	QQ 商品ID 可用于显示的名称
                 - {String}  app_id 数平支付的id 区分不同产品 目前表情填：1450000122  会员填：1450000299 超级会员：1450000306
                 - {String} [pf] 平台来源，$平台-$渠道-$版本-$业务标识  例如：mobile-1234-kjava-$大厅标识 , 业务自定义的
                 - {String} [pfkey] 跟平台来源和openkey根据规则生成的一个密钥串。内部应用填pfKey即可，不做校验
                 - {String}  product_id 苹果支付的商品ID, 手Q和sdk透传
                 - {int}    [product_type] 	(0.消费类产品 1.非消费类产品 2.包月+自动续费 3.免费 4.包月+非自动续费)
                 - {int}    [quantity] 购买数量，目前填1
                 - {int}    [is_deposit_game_coin] 是否是托管游戏币，表情商城目前不是，0
                 - {String} [pay_item] 购买明细，业务自己控制，手Q和sdk透传，存在于批价和发货整个流程里,即从批价svr获取的paytoken
                 - {String} [var_item] 这里存放业务扩展信息，如tj_plat_id=1~tj_from=vip.gongneng.xxx.xx~provider_id=1~feetype
                 @param {String} callback 回调的js函数  callback(int,String)
                 回调字段
                 - {int}    [result]
                 -1   //未知错误
                 0  //发货成功
                 1  //下订单失败
                 2  //支付失败
                 3   //发货失败
                 4    //网络错误
                 5    //登录失败或无效
                 6    //用户取消
                 7    //用户关闭IAP支付
                 -  {String} [message]
                 信息+（错误码），在提示给用户信息的同时添加错误码方便定位问题。
                 格式如：参数错误（1001）     
                 */
                pay: function(options,callback){
                    var callbackName = callback ? iOSQQApi._createGlobalFuncForCallback(callback) : null;
                    iOSQQApi._invokeClientMethod('pay', 'pay', {'params': options,
                                                 'callback': callbackName});
                },
                    
                /**
                 设置界面支持的商品种类
                 @param {Array} productIdArray
                 - {int}     QQ 商品ID  1 表情类   2 会员包月类
                 */
                enablePay: function(productIdArray){
                  
                    iOSQQApi._invokeClientMethod('pay', 'enablePay', {'params': productIdArray});
                }
            }, //pay
            
            tenpay: {
                /**
                 发起财付通现金支付请求
                 */
                pay: function(options,callback){
                    var callbackName = callback ? iOSQQApi._createGlobalFuncForCallback(callback) : null;
                    var tokenId = options.tokenId || options.tokenID;
                    delete options.tokenId;
                    delete options.tokenID;
                    options = encodeURIComponent(JSON.stringify(options));
                    var url = "mqqapiwallet://wallet/pay?src_type=web&order_no=" + tokenId
                              + "&version=1&callback_type=javascript&" + "params=" + options
                              + "&callback_name=" + callbackName;
                    window.open(url, '_self');
                },
                  
                /**
                 打开财付通业务界面
                 */
                openTenpayView: function(options,callback){
                    var callbackName = callback ? iOSQQApi._createGlobalFuncForCallback(callback) : null;
                    iOSQQApi._invokeClientMethod('pay', 'openTenpayView', {'params': options,
                                                 'callback': callbackName});
                }
            }, //tenpay
              
            sensor: {
                /**
                 开始监听重力感应数据
                 @param {Function} callback(ret, x, y, z)
                  {boolean} ret 是否成功启动传感器
                  {double} x
                  {double} y
                  {double} z
                 三个轴的数值，监听频率 50次/秒
                 @return 无
                */
                startAccelerometer: function(callback) {
                    var callbackName = mqq._createGlobalFuncForDirectCallback(callback);
                    if (callbackName) {
                        iOSQQApi._invokeClientMethod('sensor', 'startAccelerometer', {'callback': callbackName});
                    }
                },
                
                /**
                 停止监听重力感应数据
                 @param 无
                 @return 无
                */
                stopAccelerometer: function () {
                    iOSQQApi._invokeClientMethod('sensor', 'stopAccelerometer');
                },
                
                /**
                 开始监听罗盘数据
                 @param {Function} callback(ret, direction)
                   {boolean} ret 是否成功启动传感器
                   {double} direction 面对的方向度数，频率50次/秒
                 @return 无
                */
                startCompass: function(callback) {
                    var callbackName = mqq._createGlobalFuncForDirectCallback(callback);
                    if (callbackName) {
                        iOSQQApi._invokeClientMethod('sensor', 'startCompass', {'callback': callbackName});
                    }
                },
                
                /**
                 停止监听罗盘数据
                 @param 无
                 @return 无
                */
                stopCompass: function() {
                    iOSQQApi._invokeClientMethod('sensor', 'stopCompass');
                },
                
                /**
                让手机震动指定时间
                @param {Object}
                     - Number  time (毫秒)
                */
                vibrate: function(params) {
                    iOSQQApi._invokeClientMethod('sensor', 'vibrate', params);
                },
                
                /**
                 开始监听麦克风音量大小
                 @param {Function} callback(ret, volume)
                  {boolean} ret
                  {float} volume 音量大小(db)，回调频率10次/秒
                 @return 无
                */
                startListen: function(callback) {
                    var callbackName = mqq._createGlobalFuncForDirectCallback(callback);
                    if (callbackName) {
                        iOSQQApi._invokeClientMethod('sensor', 'startListen', {'callback': callbackName});
                    }
                },
                
                /**
                 停止监听麦克风音量大小
                 @param 无
                 @return 无
                */
                stopListen: function () {
                    iOSQQApi._invokeClientMethod('sensor', 'stopListen');
                },
                
                /**
                 兼容旧接口，和data.currentLocation一样
                 */
                getLocation: function(callback) {
                    var callbackName = mqq._createGlobalFuncForCallback(callback);
                    if (callbackName) {
                        return iOSQQApi.data.currentLocation(callbackName);
                    }
                    return null;
                },
 /**
  获取地理位置
  @param {Object} params
  int desiredAccuracy 地理位置精度，默认2
  1: best
  2: 100m
  3: 1000m
  4: 3000m
  int isWGS84 获取的座标类型，默认1
  0: 火星座标
  1: 地球座标
  int showAlert 当系统定位关闭时，回调函数的retCode会返回-1，此参数用于控制是否弹出alert询问用户是否打开定位，默认1
  0: 不弹框
  1: 弹框
  @param {Function} callback(int retCode, Object result)
  int retCode 返回码
  -1: 获取位置失败
  0: 获取经纬度成功
  Object result
  int type 返回的类型
  1: 基站信息
  2: 座标
  int desiredAccuracy 精度
  double lat 精度
  double lon 维度
  int isWGS84 是(1)否(0)火星座标
  int timestamp 时间戳
  */
 getRealLocation: function(params,callback){
 var callbackName = callback ? iOSQQApi._createGlobalFuncForCallback(callback) : null;
 return iOSQQApi._invokeClientMethod('data', 'getOSLocation', {'params':params,'callback':callbackName});
 }
 
            }, //sensor
 
            media: {
 
                /**
                播放离线包里的音频
                @params {Object}
                     - Number bid
                     - String url
                */
                playLocalSound: function(params) {
                    iOSQQApi._invokeClientMethod('sensor', 'playLocalSound', params);
                },

                /**
                预加载声音   
                （不过目前iOS没有预加载声音）
                
                @param {Object} params
                     - {Number} bid
                     - {String} url         //声音URL
                @param {Function} callback(ret)
                     - {Number} ret         //1加载成功，0加载失败。
                     - {String} error [可选] //失败原因（成功则为null）。
                */
                preloadSound: function(params) {
                    iOSQQApi._invokeClientMethod('sensor', 'preloadSound', params);
                },

                getPicture: function(params, callback){
                    var callbackName = iOSQQApi._createGlobalFuncForCallback(callback);
                    params.callback = callbackName;
                    iOSQQApi._invokeClientMethod('media', 'getPicture', params);
                }

            }, //media
            
            offline: {
                
                /**
                强制更新离线包，完成后回调
                @param {Object}
                     - Number bid
                @param {Function} callback(event , ret, response)
                     - Number event 回调类型 0 or 1

                    Event = 0时，判断本地是否已经有离线包
                    有：ret=1 没有：ret=0
                    Event = 1时，离线包下载完成通知
                    成功：ret=1，失败ret=0，response为错误描述
                */
                update: function(params, callback) {
                    var callbackName = iOSQQApi._createGlobalFuncForCallback(callback);
                    if (callbackName) {
                        params.callback = callbackName;
                        iOSQQApi._invokeClientMethod('offline', 'update', params);
                    }
                },

                /**
                查询本地是否有离线缓存 
                @param {Object} params
                     - {Number} bid 
                @param {Function} callback(ret)
                     - {Number} ret          //有本地缓存1，无0.
                @param {Function} callback(localVersion)
                     - {Number} localVersion //本地缓存版本号

                关于callback中的本地缓存版本号的特殊值：
                    -1: 无本地缓存。
                     0: 代表有本地缓存但是无法获取版本号（比如本地文件夹内没有config.json或者其他原因）。
                */
                isCached: function(params, callback) {
                    var callbackName = iOSQQApi._createGlobalFuncForCallback(callback);
                    if (callbackName) {
                        params.callback = callbackName;
                        iOSQQApi._invokeClientMethod('offline', 'isCached', params);
                    }
                },

                /**
                查询后台是否有更新
                param {Object} params
                     - {Number} bid
                @param {Function} callback(response)
                     - {String} response     //后台的回应JSON。

                后台JSON示例：
                    无更新：
                    {
                        "r":0,
                        "type":0
                    }
                    有更新：
                    {
                        "r":0,
                        "type":1,
                        "uptype":0,
                        "url":http://pub.idqqimg.com/xxxx.zip,
                        "version":20080
                    }
                */
                checkUpdate: function(params, callback) {
                    var callbackName = iOSQQApi._createGlobalFuncForCallback(callback);
                    if (callbackName) {
                        params.callback = callbackName;
                        iOSQQApi._invokeClientMethod('offline', 'checkUpdate', params);
                    }
                },

                /**
                下载更新（直接下载，不查询更新）    
                @param {Object} params
                     - {Number} bid 
                     - {String} url         //更新zip包URL
                @param {Function} callback(ret, error)
                     - {Number} ret         //1更新成功，0更新失败。
                     - {String} error [可选] //失败原因（成功则为null）。
                */
                downloadUpdate: function(params, callback) {
                    var callbackName = iOSQQApi._createGlobalFuncForCallback(callback);
                    if (callbackName) {
                        params.callback = callbackName;
                        iOSQQApi._invokeClientMethod('offline', 'downloadUpdate', params);
                    }
                },

                /**
                （离线包拉取成功后）刷新本地缓存使新离线包生效
                */
                refreshOfflineCache: function() {
                    iOSQQApi._invokeClientMethod('offline', 'refreshOfflineCache');
                }

            }, //offline
            
            ui: {
                /**
                 调用之后关闭当前WebView，返回到AIO聊天窗口
                 @param 无
                 @returns 无
                 */
                returnToAIO: function() {
                    iOSQQApi._invokeClientMethod('nav', 'returnToAIO');
                },
                
                /**
                 @param {Object}
                  String url
                  int [target]
                  String [relatedAccount]
                  String [relatedAccountType]
                  
                  @return {void}
                  
                  target:
                  0: 在当前webview打开
                  1: 在新webview打开
                  2: 在外部浏览器上打开（iOS为Safari,Android为系统默认浏览器）
                  
                  style（只对target=1有效）:
                  0: 顶部控制栏模式（默认）
                  1: 顶部控制栏无分享入口
                  2: 底部工具栏模式（顶部的bar依然会存在）
                  3: 底部工具栏无分享入口（顶部的bar依然会存在）
                  
                  relatedAccount和relatedAccountType用于传入与该webview相关的帐号和帐号类型，比如传入公众帐号可在分享菜单里显示相关的分享选项（同样只对target=1有效）：
                  relatedAccountType:
                  ‘officalAccount’：公众帐号
                  
                  @example
                  mqq.ui.openUrl({
                     url: ‘http://web.qq.com’,
                     target: 1,
                     style: 3
                  });
                 */
                openUrl: function(options) {
                    if (!options) {
                        options = {};
                    }
                    switch (options.target) {
                        case 0:
                            window.open(options.url, '_self');
                            break;
                        case 1:
                            iOSQQApi.nav.openLinkInNewWebView(options.url, options);
                            break;
                        case 2:
                            iOSQQApi.nav.openLinkInSafari(options.url);
                            break;
                    }
                },
                /**
                 返回打开webview的上一层view controller
                 */
                popBack: function(){
                    iOSQQApi._invokeClientMethod('nav', 'popBack');
                },
                
                /**
                 按指定方式重刷当前页面
                 */
                reload: function(options){
                    iOSQQApi._invokeClientMethod('nav', 'reload', options);
                },
                
                showLoading: function(){
                    iOSQQApi._invokeClientMethod('nav', 'showLoading');
                },
                hideLoading: function(){
                    iOSQQApi._invokeClientMethod('nav', 'hideLoading');
                },
                setLoadingColor: function(r, g, b){
                    iOSQQApi._invokeClientMethod('nav', 'setLoadingColor', {'r':r, 'g':g, 'b':b});
                },
                
                setLoading: function(params) {
                    if (params) {
                        //文档上要求如果visible没有值，不去改变菊花。
                        if (params.visible === true) {
                            this.showLoading();
                        } else if (params.visible === false) {
                            this.hideLoading();
                        }

                        if (params.color) {
                            this.setLoadingColor(params.color[0], params.color[1], params.color[2]);
                        }
                    }
                },
                /**
                 设置webview右上角按钮的标题和回调，若全部留空则会隐藏该按钮
                 */
                setActionButton: function(title, callback){
                    var callbackName = callback ? iOSQQApi._createGlobalFuncForCallback(callback) : null;
                    var parameter = (typeof title == 'object' ? title : {'title':title});
                    parameter['callback'] = callbackName;
                    iOSQQApi._invokeClientMethod('nav', 'setActionButton', parameter);
                },
                /**
                 设置webview右上角按钮的标题、样式和回调（样式尚未决定要如何改），若options为空则会隐藏该按钮
                 */
                setActionButtonWithOptions: function(options){
                    //TODO 睇睇要点样修改按钮样式（改颜色？还是固定几种样式？）
                },

                /**
                    推入展示指定个人名片 群名片view controller
                    @param {Object} param uin or {'uin':uin, ...}
                        - {String} uin
                        - {int} uinType  0或 不填 好友名片， 1 群名片
                 
               */
                showProfile: function(options){
                    iOSQQApi._invokeClientMethod('nav', 'showProfile', options);
                 },
            
                /**
                 推入展示指定公众帐号详情信息的view controller，或者公众帐号AIO
                 @param {String|Object} param uin or {'uin':uin, ...}
                 */
                showOfficalAccountDetail: function(param){
                    var parameter = (typeof param == 'object' ? param : {'uin':param});
                    iOSQQApi._invokeClientMethod('nav', 'showOfficalAccountDetail', parameter);
                },
                
                /**
                 推入新WebView来打开指定url
                 @param {String} url
                 @param {Object} options 用于控制WebView的展现和行为
                     - {String} style               WebView样式，可取如下值：
                     - 'topbar'                      顶部控制栏模式（默认）/1
                     - 'topbarWithoutShare'          顶部控制栏模式（没分享入口）/4
                     - 'bottombar'                   底部工具栏模式 /2
                     - 'bottombarWithoutShare'       底部工具栏模式（没分享入口）/5
                     - {String} relatedAccount       相关帐号
                     - {String} relatedAccountType   相关帐号类型
                     - 'officalAccount'              公众帐号
                     - {int} openInCouponWebview
                 */
                openLinkInNewWebView: function(url, options){
                    if (!options) {
                        options = {};
                    }
                    options.styleCode = 1;
                    switch(options.style){
                        case 1:
                        case 'topbarWithoutShare':
                            options.styleCode = 4; break;

                        case 2:
                        case 'bottombar':
                            options.styleCode = 2; break; 

                        case 3:
                        case 'bottombarWithoutShare':
                            options.styleCode = 5; break; 

                        default:
                            options.styleCode = 1; break;
                    }
                    iOSQQApi._invokeClientMethod('nav', 'openLinkInNewWebView', {'url':url, 'options':options});
                },
            
                openLinkInSafari: function(url){
                    iOSQQApi._invokeClientMethod('nav', 'openLinkInSafari', {'url':url});
                },
                
                /**
                 打开指定的viewController
                 @param {Object} options
                     - {String} name viewController的名字，可取如下值：
                     - 'ChatAvatarSetting'   聊天气泡
                     - 'MarketFace'          表情商城
                     - 'Coupon'              优惠券
                     - 'UserSummary'         用户自己的资料页面
                 */
                openViewController: function(options){
                    iOSQQApi._invokeClientMethod('nav', 'openViewController', options);
                },
                openView: function(options){
                    mqq.ui.openViewController(options);
                },
                
                /**
                 打开选择好友的ViewController
                 @param {Object} options
                     - {int} appid AppID
                     - {String} title ViewController的标题，默认是当前群/讨论组的名字
                     - {int} [min] 最少需要选多少人，默认为0
                     - {int} [max] 最多允许选多少人，默认无上限
                     - {int} [guin] 群/讨论组的uin，默认就是打开这个webview的群/讨论组的uin
                     - {Function/String} callback 选择完成后的回调函数，参数列表：callback(code[, result])
                 */
                selectFriends: function(options){
                    var callbackName = options.callback ? iOSQQApi._createGlobalFuncForCallback(options.callback) : null;
                    options.callback = callbackName;
                    iOSQQApi._invokeClientMethod('nav', 'selectFriends', options);
                },
                
                /**
                 发定向分享消息给好友/群/讨论组
                 @param {Object} options
                     - {int} appid AppID，用来显示来源的
                     - {int} [uin] 好友/群/讨论组的uin，默认就是打开这个webview的好友/群/讨论组的uin
                     - {int} [type] 类型，是好友(1)、群(2)还是讨论组(3)，如果指定了uin参数就必须填type，否则可以留空，客户端会自动判断
                     - {String} title 消息标题
                     - {String} summary 消息摘要
                     - {String} actionUrl 点击消息后的跳转url
                     - {String} imageUrl 消息左侧缩略图的url
                     - {bool} [hideImageBorder] 缩略图是否要隐藏边框，默认是有边框的
                     - {bool} [returnToAIO] 发送消息之后是否返回到AIO，默认不返回、留在当前页面
                 */
                shareMessage: function(options){
                    iOSQQApi._invokeClientMethod('nav', 'shareMessage', options);
                },

                /**
                弹出一个确认框
                @param {Object}
                     - String title
                     - String text
                     - Boolean [needOkBtn] //是否显示确认按钮，默认true
                     - Boolean [needCancelBtn] //是否显示取消按钮，默认true
                @param {Function} [callback(result)]
                     - result.button == 0, //点击了确认按钮
                     - result.button == 1,//点击了取消按钮
                */
                showDialog: function(params, callback) {
                    if(params) {
                        params['callback'] = iOSQQApi._createGlobalFuncForCallback(callback);
                        mqq._invokeClientMethod('nav', 'showDialog', params);
                    }
                },

                /**
                 以公众账号的身份调用native分享接口
                 @param {Object} params
                      - {String} oaUin 公众账号uin
                      - {String} title 消息标题
                      - {String} summary 消息摘要
                      - {String} targetUrl 点击消息后的跳转url
                      - {String} imageUrl 消息左侧缩略图url
                      - {String} [sourceName] 消息来源名称，默认为空，直接读取oaUin对应的公众账号名称
                      - {Boolean} [back] 发送消息之后是否返回到web页面，默认NO，直接到AIO
                 @param {Function} [callback(result)]
                        result.ret == 0, // 用户点击发送，完成整个分享流程
                        result.ret == 1, // 用户点击取消，中断分享流程
                        result.ret == 2, // 分享参数验证失败
                 */
                officalAccountShareRichMsg2QQ: function(params, callback) {
                    if (typeof params == 'object') {
                        var callbackName = callback ? iOSQQApi._createGlobalFuncForCallback(callback) : null;
                        params['callback'] = callbackName;
                        iOSQQApi._invokeClientMethod('nav', 'officalAccountShareRichMsg2QQ', params);
                    }
                },

                /**
                 打开QQ商家资料卡
                 @param {Object} params
                      - {String} uin 企业QQ账号uin
                      - {String} sigt sigt标识
                 */
                showEQQ : function(params) {
                    iOSQQApi._invokeClientMethod('nav', 'showEQQ', params);
                }
                ,
                shareAudio: function(params,callback){
                   var callbackName = callback ? iOSQQApi._createGlobalFuncForCallback(callback) : null;
                   return iOSQQApi._invokeClientMethod('nav', 'shareAudio', {'params':params,'callback':callbackName});
                }
                ,
                /**
                 设置webveiw关闭的回调函数
                 当设置后，webveiw关闭时，会调用设置进来的JS函数，不执行关闭：
                
                 警告：警告：保证页面能正确执行JS函数，在页面内跳转后请设置此回调函数为空，否则JS函数如在页面不能执行，导致界面无法退出。
                 @param {Object} 暂空
                 @param {Function} [callback()]

                */
                setOnCloseHandler: function(params,callback){
                   var callbackName = callback ? iOSQQApi._createGlobalFuncForCallback(callback) : null;
                   return iOSQQApi._invokeClientMethod('ui', 'setOnCloseHandler', {'params':params,'callback':callbackName});
                }

            }, //ui
 
             group:
             {
                getMemberList:function(uin,callbackName){
                    return iOSQQApi._invokeClientMethod('troopMember','getMemberList',
                                                 {
                                                 'uin':uin,
                                                 'callbackName':callbackName
                                                 });
                },
             
                setTroopNick:function(groupCode,uin,nick,callbackName){
                    return iOSQQApi._invokeClientMethod('troopMember','setTroopNick',
                                                 {
                                                 'groupCode':groupCode,
                                                 'uin':uin,
                                                 'nick':nick,
                                                 'callbackName':callbackName
                                                 });
                },
             
                showPersonalLevel:function(groupCode,uin){
                    return iOSQQApi._invokeClientMethod('troopMember','showPersonalLevel',
                                                 {
                                                 'groupCode':groupCode,
                                                 'uin':uin
                                                 });
                },
             
                setSpeakStatus:function(groupCode,uin,callbackName){
                    return iOSQQApi._invokeClientMethod('troopMember','setSpeakStatus',
                                                 {
                                                 'groupCode':groupCode,
                                                 'uin':uin,
                                                 'callbackName':callbackName
                                                 });
                },
             
                showPersonalCard:function(uin,callbackName){
                    return iOSQQApi._invokeClientMethod('troopMember','showPersonalCard',
                                                 {
                                                 'uin':uin,
                                                 'callbackName':callbackName
                                                 });
                },
             
                getTroopMemberInfo:function(groupCode,uin){
                    return iOSQQApi._invokeClientMethod('troopMember','getTroopMemberInfo',
                                                 {
                                                 'groupCode':groupCode,
                                                 'uin':uin
                                                 });
                },
             
                getMemberFace:function(uinList,callbackName){
                    return iOSQQApi._invokeClientMethod('troopMember', 'getMemberFace',
                                                 {
                                                 'uinList':uinList,
                                                 'callbackName':callbackName
                                                 });
                }
             
             }//group
 
        };

        iOSQQApi = mqq;
        iOSQQApi.nav = mqq.ui;
    }

})();
 


